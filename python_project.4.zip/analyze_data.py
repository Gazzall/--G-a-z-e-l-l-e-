
import pandas as pd

# Load the data files
users_data = pd.read_json('users_000001.json', lines=True)
repos_data = pd.read_json('repositories_000001.json', lines=True)

# Display data summaries
print("Users Data:")
print(users_data.head())

print("\nRepositories Data:")
print(repos_data.head())

# Analyze data (example: counting users or repositories)
print(f"Total Users: {len(users_data)}")
print(f"Total Repositories: {len(repos_data)}")

# You can extend this script to add more functionality or analysis!
